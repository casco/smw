<?php

namespace SMW\SQLStore\EntityStore\Exception;

use RuntimeException;

/**
 * @license GNU GPL v2+
 * @since 2.5
 *
 * @author mwjames
 */
class DataItemHandlerException extends RuntimeException {


}
