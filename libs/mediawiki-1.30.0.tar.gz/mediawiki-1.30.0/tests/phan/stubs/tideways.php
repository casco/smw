<?php

/**
 * Minimal set of classes necessary for Xhprof using tideways
 * @codingStandardsIgnoreFile
 */

function tideways_enable(){
}

function tideways_disable(){
}
