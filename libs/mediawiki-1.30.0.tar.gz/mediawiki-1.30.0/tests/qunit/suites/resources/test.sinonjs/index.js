// Hack: Disable 'module.exports' from ResourceLoader
// (Otherwise Sinon assumes context as Node.js instead of a browser)
module.exports = null;
