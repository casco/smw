<?php

class PhpHttpRequestTest extends MWHttpRequestTestCase {
	protected static $httpEngine = 'php';
}
