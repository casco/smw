<?php

class CurlHttpRequestTest extends MWHttpRequestTestCase {
	protected static $httpEngine = 'curl';
}
