<?php
/**
 * Test file for testing ServiceContainer::loadWiringFiles
 */

return [
	'Foo' => function () {
		return 'Foo!';
	},
];
