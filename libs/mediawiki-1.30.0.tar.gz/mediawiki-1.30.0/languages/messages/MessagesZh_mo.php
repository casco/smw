<?php
/** ‪Chinese (Macau) (‪中文(澳門)‬)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-hk, zh-hant, zh-hans';
